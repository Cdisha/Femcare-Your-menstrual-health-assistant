function playVideo(id) {
    let video = document.getElementById(id);
    video.play();
}

function pauseVideo(id) {
    let video = document.getElementById(id);
    video.pause();
}
